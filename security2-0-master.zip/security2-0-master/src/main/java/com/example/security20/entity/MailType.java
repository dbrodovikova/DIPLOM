package com.example.security20.entity;

public enum MailType {
    REGISTRATION
}
