package com.example.security20;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Security20Application {

    public static void main(String[] args) {
        SpringApplication.run(Security20Application.class, args);
    }

}
