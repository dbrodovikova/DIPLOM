package com.example.security20;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Security20ApplicationTests {

    @Test
    void contextLoads() {
    }

}
